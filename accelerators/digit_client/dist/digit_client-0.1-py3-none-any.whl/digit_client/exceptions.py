class UserError(Exception):
    pass

class ServiceRequestError(Exception):
    pass

class BoundaryError(Exception):
    pass

# Add more exception classes as needed