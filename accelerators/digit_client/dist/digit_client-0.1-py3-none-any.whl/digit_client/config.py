class Config:
    API_ENDPOINT = "https://example.com/api"  # Set your API endpoint
    AUTH_TOKEN = "your_auth_token"              # Set your authentication token