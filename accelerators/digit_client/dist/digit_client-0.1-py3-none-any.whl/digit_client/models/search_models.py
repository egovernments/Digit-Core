from typing import List, Optional
from dataclasses import dataclass, field

@dataclass
class UserSearchModel:
    """Model for user search criteria"""
    tenantId: str  # Using exact field names from API
    userType: Optional[str] = None  # Changed from type to userType
    active: Optional[bool] = None
    uuid: Optional[List[str]] = None
    userName: Optional[str] = None  # Changed from user_name to userName
    
    def to_dict(self) -> dict:
        """Convert the search model to a dictionary for API request"""
        search_dict = {
            "tenantId": self.tenantId
        }
        
        if self.userType is not None:
            search_dict["userType"] = self.userType
            
        if self.active is not None:
            search_dict["active"] = str(self.active).lower()  # Convert to "true" or "false" string
            
        if self.uuid:
            search_dict["uuid"] = self.uuid
            
        if self.userName:
            search_dict["userName"] = self.userName
            
        return search_dict 