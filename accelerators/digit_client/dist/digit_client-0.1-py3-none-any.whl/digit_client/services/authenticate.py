from typing import Dict, Optional
from ..api_client import APIClient
from ..models.auth import AuthenticationRequest
from ..request_config import RequestConfig

class AuthenticationService:
    def __init__(self, api_client: Optional[APIClient] = None):
        self.api_client = api_client or APIClient()
        self.base_url = "user"

    def get_auth_token(self, auth_request: AuthenticationRequest) -> Dict:
        """
        Get authentication token using password grant type
        
        Args:
            auth_request (AuthenticationRequest): Authentication request model containing credentials
            
        Returns:
            Dict: Response containing the auth token
        """
        headers = {
            'Authorization': 'Basic ZWdvdi11c2VyLWNsaWVudDo=',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        return self.api_client.post(
            "oauth/token",
            data=auth_request.to_dict(),
            additional_headers=headers
        )

    def logout(self, access_token: str) -> Dict:
        """
        Logout the user using their access token
        
        Args:
            access_token (str): The access token to invalidate
            
        Returns:
            Dict: Response from the logout API
        """
        # Get request info for logout action
        request_info = RequestConfig.get_request_info(
            action="POST",
            msg_id="logout-user",
            temp_auth_token=access_token
        )
        
        payload = {
            "RequestInfo": request_info.to_dict()
        }
        
        # Add access token as query parameter
        params = {
            "access_token": access_token
        }
        
        endpoint = f"{self.base_url}/_logout"
        return self.api_client.post(
            endpoint,
            json_data=payload,
            params=params
        )